<?php
    session_start();
    $_SESSION['fname'] = $_POST['fname'];
    $_SESSION['lname'] = $_POST['lname'];
    $_SESSION['uname'] = $_POST['uname'];
    $_SESSION['password'] = $_POST['password'];
    $_SESSION['email'] = $_POST['email'];
    $_SESSION['number'] = $_POST['number'];
    $_SESSION['dob'] = $_POST['dob'];
    $_SESSION['age'] = $_POST['age'];
    $_SESSION['gender'] = $_POST['gender'];
    $_SESSION['drive'] = $_POST['drive'];
    $_SESSION['licensenumber'] = $_POST['licensenumber'];
    $_SESSION['college'] = $_POST['college'];
    $_SESSION['degree'] = $_POST['degree'];
    $_SESSION['address'] = $_POST['address'];
    $_SESSION['state'] = $_POST['state'];
    $_SESSION['country'] = $_POST['country'];
    $_SESSION['code'] = $_POST['code'];
    
?>

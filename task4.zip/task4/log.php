<?php
    session_start();
 

    $_SESSION['uname'] = $_POST['uname'];
    $_SESSION['password'] = $_POST['password'];

   
   
?>